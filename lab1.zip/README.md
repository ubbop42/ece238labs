To build the program, enter the following command: make
To run the program, enter the following command: make run
To clean the program, enter the following command: make clean

output files:
The program will output 2 csv files; mm1_results.csv and mm1k_results.csv.

mm1_results.csv will answer question 3 and 4

mm1k_results.csv will answer question 6.

question1/question1.c is the c code to answer question 1.