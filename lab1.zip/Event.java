public class Event {
    String type;
    double time;

    Event(String type, double time) {
        this.type = type;
        this.time = time;
    }
}